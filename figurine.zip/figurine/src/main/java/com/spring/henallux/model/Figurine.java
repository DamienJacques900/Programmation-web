package com.spring.henallux.model;

public class Figurine 
{
	private String name;
	private double weight;
	private double size;
	public Figurine()
	{
		
	}
	
	public String getName()
	{
		return name;
	}
	
	public double getWeight()
	{
		return weight;
	}
	
	public double getSize()
	{
		return size;
	}
	
	public void setName(String n)
	{
		name = n;
	}
	
	public void setWeight(double w)
	{
		weight = w;
	}
	
	public void setSize(double s)
	{
		size = s;
	}
}
