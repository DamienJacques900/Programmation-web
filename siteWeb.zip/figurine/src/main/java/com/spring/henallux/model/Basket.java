package com.spring.henallux.model;

public class Basket 
{
	public Basket()
	{
		
	}
}
