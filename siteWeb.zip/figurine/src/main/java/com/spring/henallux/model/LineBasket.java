package com.spring.henallux.model;

public class LineBasket 
{
	private int nbFigurine;
	
	public LineBasket()
	{
		
	}
	
	//GETTERS =====================================================
	public int getNbFigurine()
	{
		return nbFigurine;
	}
	
	//SETTERS =====================================================
	public void setNbFigurine(int nb)
	{
		nbFigurine = nb;
	}
}
