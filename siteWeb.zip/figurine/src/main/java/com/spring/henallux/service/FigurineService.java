package com.spring.henallux.service;

public class FigurineService 
{

}
