package com.spring.henallux.model;

public class VideoGames extends Work
{
	private String support;
	
	public VideoGames()
	{
		super();
	}
	
	//GETTERS =====================================================
	public String getSupport()
	{
		return support;
	}
	
	//SETTERS =====================================================
	public void getSupport(String s)
	{
		support = s;
	}

}
