package com.spring.henallux.model;

public class Animation extends Work
{
	private String country;
	private String studio;
	
	public Animation()
	{
		super();
	}
	
	//GETTERS =====================================================
	
	
	//SETTERS =====================================================
	
	
}
